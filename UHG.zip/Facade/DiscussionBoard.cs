﻿namespace Facade
{
    internal class DiscussionBoard
    {
        public DiscussionBoard()
        {

        }
    }
}