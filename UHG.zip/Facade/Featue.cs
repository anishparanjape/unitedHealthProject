﻿namespace Facade
{
    internal class Featue
    {
        private string feature;


        public Featue()
        {
        }

        public Featue(string feature)
        {
            this.Feature = feature;
        }

        public string Feature { get => feature; set => feature = value; }
    }
}