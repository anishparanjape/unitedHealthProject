﻿namespace Facade
{
    internal class Page
    {
        private string name;

        public Page()
        {
        }

        public Page(string name)
        {
            this.Name = name;
        }

        public string Name { get => name; set => name = value; }
    }
}