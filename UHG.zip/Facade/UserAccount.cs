﻿namespace Facade
{
    internal class UserAccount
    {
        private string username;

        public UserAccount()
        {
        }

        public UserAccount(string uname)
        {
            this.Username = uname;
        }

        public string Username { get => username; set => username = value; }
    }
}