﻿namespace Facade
{
    internal class UserRole
    {
        private string rolename;

        public UserRole()
        {
        }

        public UserRole(string role)
        {
            this.Rolename = role;
        }

        public string Rolename { get => rolename; set => rolename = value; }
    }
}