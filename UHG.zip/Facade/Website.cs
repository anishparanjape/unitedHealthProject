﻿using System;
using System.Collections.Generic;
using System.Threading;

namespace Facade
{
    internal class Website
    {
        public Website()
        {
        }

        internal void CreateUserAccounts(List<UserAccount> list)
        {
            Thread.Sleep(2000);
            foreach (var ua in list)
            {
                Console.WriteLine("Created User Accounts for: " + ua.Username);
            }
        }

        internal void CreateUserRoles(List<UserRole> list)
        {
            Thread.Sleep(2000);
            foreach (var ua in list)
            {
                Console.WriteLine("Created User Role: " + ua.Rolename);
            }
        }

        internal void AssignRoletoAccount(UserRole role, UserAccount account)
        {
            Thread.Sleep(2000);
            Console.WriteLine("Assigned Role: " + role.Rolename + " to " + account.Username);
        }

        internal void CreateSiteHomePage(Page page)
        {
            Thread.Sleep(2000);
            Console.WriteLine("Created Home Page: " + page.Name);
        }

        internal void CreateSiteDiscussionBoard(DiscussionBoard discussions)
        {
            Thread.Sleep(2000);
            Console.WriteLine("Created Site Discussion Board");
        }

        internal void AddSiteFeature(Featue feature)
        {
            Thread.Sleep(2000);
            Console.WriteLine("Created Site Feature: " + feature.Feature);
        }
    }
}