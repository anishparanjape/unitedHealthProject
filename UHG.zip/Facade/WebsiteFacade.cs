﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Facade
{
    internal class WebsiteFacade
    {

        internal void CreateWebSite(List<Featue> features)
        {

            // first create admin account
            var website = new Website();
            var account = new UserAccount("Admin");
            website.CreateUserAccounts(new List<UserAccount>() { account }); 

            // create a rolw with full permission
            var role = new UserRole("Full Permission");
            website.CreateUserRoles(new List<UserRole>() { role });

            // assign full permissions to admin
            website.AssignRoletoAccount(role, account);

            // create site home page
            var page = new Page("Home");
            website.CreateSiteHomePage(page);

            // create site discussion board
            var discussions = new DiscussionBoard();
            website.CreateSiteDiscussionBoard(discussions);

            // for each extra feature provided by the client, add this feature to the site
            foreach (var feature in features)
            {
                website.AddSiteFeature(feature);
            }


        }
    }
}
