﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Memento
{
    class Memento
    {
        private string version;

        public Memento(string v)
        {
            version = v;
        }

        public string GetVersion()
        {
            return version;
        }
    }
}
