﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace Memento
{
    class TestTFSMemento
    {
        static void Main(string[] args)
        {
            var mementos = new List<Memento>();

            var versionControl = new TfsVersionControl();
            Memento memento;

            Console.WriteLine("Setting Version 1");
            Thread.Sleep(2000);
            memento = versionControl.SetVersion("V_1.0");
            mementos.Add(memento);
            Console.WriteLine("Current Version: " + versionControl.GetVersion());


            Console.WriteLine("Setting Version 2");
            Thread.Sleep(2000);
            memento = versionControl.SetVersion("V_2.0");
            mementos.Add(memento);
            Console.WriteLine("Current Version: " + versionControl.GetVersion());


            Console.WriteLine("Setting Version 3");
            Thread.Sleep(2000);
            memento = versionControl.SetVersion("V_3.0");
            mementos.Add(memento);
            Console.WriteLine("Current Version: " + versionControl.GetVersion());


            Console.WriteLine("Reverting to Previous Version");
            Thread.Sleep(2000);
            versionControl.RevertToPreviousVersion((Memento)mementos.Last());
            mementos.Remove(mementos.Last());
            Console.WriteLine("Current Version: " + versionControl.GetVersion());

            Console.WriteLine("Reverting to Previous Version");
            Thread.Sleep(2000);
            versionControl.RevertToPreviousVersion((Memento)mementos.Last());
            mementos.Remove(mementos.Last());
            Console.WriteLine("Current Version: " + versionControl.GetVersion());


        }
    }
}
