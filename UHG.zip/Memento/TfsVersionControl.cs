﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Memento
{
    class TfsVersionControl
    {
        private string version;

        public Memento SetVersion(string v)
        {
            var memento = new Memento(this.version);
            this.version = v;
            return memento;
        }

        public string GetVersion()
        {
            return this.version;
        }

        public void RevertToPreviousVersion(Memento prevVersion)
        {
            this.version = prevVersion.GetVersion();
        }
    }


}
