﻿using System;
using System.Threading;

namespace Template
{
    abstract public class BackendQueryTemplate
    {
        public BackendQueryTemplate()
        {
        }

        public abstract void ExecuteQuery();

        internal void QueryBackend(string dataSource)
        {
            Console.WriteLine("Connection Opened with " + dataSource + " DataSource");

            Thread.Sleep(2000);
            ExecuteQuery();

            Thread.Sleep(2000);
            Console.WriteLine("Query Results Obtained");

            Thread.Sleep(2000);
            Console.WriteLine("Connection Closed with " + dataSource);

        }
    }
}