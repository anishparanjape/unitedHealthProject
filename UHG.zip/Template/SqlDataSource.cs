﻿using System;

namespace Template
{
    internal class SqlDataSource : BackendQueryTemplate
    {
        public override void ExecuteQuery()
        {
            Console.WriteLine("Executed Query from Sql");
        }
    }
}