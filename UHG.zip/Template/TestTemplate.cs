﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Template
{
    class TestTemplate
    {
        static void Main(string[] args)
        {

            var sqlTemplate = new SqlDataSource();
            sqlTemplate.QueryBackend("SQL");
            Console.WriteLine(".....................................");

            var xmlTemplate = new XMLDataSource();
            xmlTemplate.QueryBackend("XML");
            Console.WriteLine(".....................................");


        }
    }
}
