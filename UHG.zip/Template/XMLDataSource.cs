﻿using System;

namespace Template
{
    internal class XMLDataSource : BackendQueryTemplate
    {
        public override void ExecuteQuery()
        {
            Console.WriteLine("Executed Query from XML");
        }
    }
}