﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Collections;
using System.Text;

namespace UHGTest
{
    /*
        
     we perform binary search on our arra, this will ensure equal number of nodes are provided 
     to both left and right subtree.
         
    */
    public class GenerateTree
    {

        public TreeNode GetBST(int[] sortedTree)
        {

            if (sortedTree.Length < 1) return null;
            var mid = sortedTree.Length / 2;

            var root = new TreeNode(sortedTree[mid]);
            if (mid > 0)
            {
                var leftArr = new int[mid];

                Array.Copy(sortedTree, 0, leftArr, 0, mid);
                root.left = GetBST(leftArr);

                var rightArr = new int[sortedTree.Length - mid-1];
                Array.Copy(sortedTree, mid + 1, rightArr, 0, sortedTree.Length - mid-1);
                root.right = GetBST(rightArr);
            }
            return root;
        }

        public List<int> InOrder(TreeNode root, List<int> arr)
        {
            if (root == null)
            {
                return new List<int>();
            }
            InOrder(root.left, arr);
            arr.Add(root.val);
            InOrder(root.right, arr);
            return arr;
        }

    }
}
