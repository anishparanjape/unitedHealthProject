﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Collections;
using System.Diagnostics;

namespace UHGTest
{
    class UnitTest
    {
        static void Main(string[] args)
        {
            // test sample array
            GenerateTree treeOperations = new GenerateTree();
            var input = new int[] { 1, 2, 3, 4, 5, 6 };
            TreeNode node = treeOperations.GetBST(input);
            var testArr = treeOperations.InOrder(node, new List<int>()).ToArray();
            Debug.Assert(testArr.SequenceEqual(input));



            // empty
            input = new int[]{ };
            node = treeOperations.GetBST(input);
            testArr = treeOperations.InOrder(node, new List<int>()).ToArray();
            Debug.Assert(testArr.SequenceEqual(input));


            // 1 element
            input = new int[] { 5};
            node = treeOperations.GetBST(input);
            testArr = treeOperations.InOrder(node, new List<int>()).ToArray();
            Debug.Assert(testArr.SequenceEqual(input));



            // random test
            input = new int[] { 5 , 7,19, 30,172,9393};
            node = treeOperations.GetBST(input);
            testArr = treeOperations.InOrder(node, new List<int>()).ToArray();
            Debug.Assert(testArr.SequenceEqual(input));


        }
    }


}
